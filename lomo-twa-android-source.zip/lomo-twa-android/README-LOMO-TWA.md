# LoMo Android TWA project

This bundle bypasses the PWA Builder web analyzer. It is a standard Bubblewrap / Android Browser Helper Trusted Web Activity project.

## Critical configuration

- Package name / applicationId: `world.lomo.www.twa`
- Host: `www.lomo.world`
- Start URL: `https://www.lomo.world/`
- Manifest URL: `https://www.lomo.world/manifest.webmanifest`
- App name: `LoMo — Location & Movement`
- Launcher name: `LoMo`

## Files included

- `twa-manifest.json` — Bubblewrap source config
- `app/build.gradle` — Android applicationId is set to `world.lomo.www.twa`
- `app/src/main/AndroidManifest.xml` — TWA launcher and URL intent filters
- `web-deployment/.well-known/assetlinks.json` — current live Digital Asset Links file
- `web-deployment/manifest.webmanifest` and `manifest.json` — current web manifests
- `.github/workflows/build-unsigned-aab.yml` — optional mobile-friendly cloud build workflow

## Important signing note

Google Play and TWA verification depend on the signing certificate. Your current live `assetlinks.json` trusts this SHA-256 fingerprint:

`55:F5:F6:CE:10:7B:D7:74:61:1B:E2:04:25:AE:1C:BA:01:F9:A2:31:8B:57:76:77:C2:D6:36:51:66:6B:86:1B`

To keep full-screen TWA trust, the final signed AAB must be signed with the matching key, OR you must update `/.well-known/assetlinks.json` with the SHA-256 fingerprint of the key used to sign the final app.

## Build options

### Option A — Android Studio / command line

Run:

`./gradlew bundleRelease`

The unsigned bundle appears at:

`app/build/outputs/bundle/release/app-release.aab`

Then sign it with your Play upload key.

### Option B — GitHub Actions from a phone

1. Create a private GitHub repository.
2. Upload all files from this folder.
3. Open the Actions tab.
4. Run "Build unsigned Android App Bundle".
5. Download the generated AAB artifact.
6. Sign it with your existing Play upload key, or use a signing workflow with GitHub Secrets if you have the keystore.

This avoids PWA Builder completely.

### Option C — GitHub Actions signed AAB

The bundle also includes `.github/workflows/build-signed-aab.yml`. Use it if you can add these repository secrets from GitHub mobile/desktop:

- `ANDROID_KEYSTORE_BASE64` — your upload keystore file encoded as base64
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_PASSWORD`
- `ANDROID_KEY_ALIAS`

This workflow outputs a signed `.aab` ready for Play Console, provided the keystore matches your Play upload key.
